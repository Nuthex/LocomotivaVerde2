package it.locomotivaverde2.locomotivaverde2.supporto;

public class ResponseMessage {
    private String message;


    public ResponseMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }


}

