package it.locomotivaverde2.locomotivaverde2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Locomotivaverde2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
